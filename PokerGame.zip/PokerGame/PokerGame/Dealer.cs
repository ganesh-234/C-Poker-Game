﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerGame
{
    public class Dealer
    {
          public void Shuffle(){    }
        public void Deal() { }
        public void Burn() { }
        public void ShowNextCard() { }
    }
 
}
