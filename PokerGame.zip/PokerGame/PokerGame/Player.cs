﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerGame
{
    public class Player
    {
        public string Name;
        public int ChipCount;
        public int Position;
        public List<Card> Hand;
        public string Status;
    }
}
