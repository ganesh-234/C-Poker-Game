﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerGame
{
    public class Table
    {
        public List<Player> Players;
        public int PotSize;
        public List<Card> Board;
        public List<Card> DiscardPile;
        public List<Card> Deck;
    }
}
